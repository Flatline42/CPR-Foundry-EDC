/**
 * CPR Skill Request — skill-request.js
 * ======================================
 * GM tool for Cyberpunk RED (Foundry VTT v12).
 * Posts an interactive skill check request card to chat.
 * Players click their button to open the native CPR skill roll dialog.
 *
 * USAGE (from a macro):
 *   game.modules.get("cpr-skill-request").api.requestSkillCheck();
 *
 * ======================================================================
 * TODO — POST v0.93 ROLL API UPDATE
 * ======================================================================
 * When CPR system v0.93 ships, replace the rollItemMacro call in
 * executeSkillRoll() below with the new native roll API. Based on the
 * v0.93 wiki, the correct replacement will be something like:
 *
 *   const actor = game.user.character;
 *   const roll = await new Roll(
 *     `1d10red + @stats.${statKey} + @skills.${skillSlug}`,
 *     actor.getRollData()
 *   ).evaluate();
 *   roll.toMessage({ speaker: ChatMessage.getSpeaker({ actor }) });
 *
 * Where skillSlug is the camelCase version of the skill name per the
 * v0.93 roll data reference (e.g. "humanPerception", "resistTortureOrDrugs").
 *
 * The function executeSkillRoll() is the ONLY place that needs changing.
 * Everything else (card building, button handling, state tracking) is
 * independent of the roll system and will not need updating.
 * ======================================================================
 */

const MODULE_ID = "cpr-skill-request";

/* ============================================================
   ROLL EXECUTION
   ============================================================ */

/**
 * Fires the CPR native skill roll interface for the current user's actor.
 * Returns true if the roll was initiated successfully — i.e. the currently
 * controlled token matches the expected actorId and has the skill.
 *
 * PRE-v0.93: Uses rollItemMacro which triggers CPR's existing roll dialog.
 * POST-v0.93: Replace this body with the new Roll API (see header TODO).
 * When replacing, the actorId param can be used to get the actor directly:
 *   const actor = game.actors.get(actorId);
 *
 * @param {string} skillName - The display name of the skill to roll.
 * @param {string} actorId - The expected actor ID for this button.
 * @returns {boolean}
 */
function executeSkillRoll(skillName, actorId) {
  try {
    const actor = game.actors.get(actorId);
    if (!actor) {
      ui.notifications.warn("Actor not found.");
      return false;
    }

    // Verify the actor has the skill
    const skill = actor.items.find(
      i => i.type === "skill" && i.name === skillName
    );
    if (!skill) {
      ui.notifications.warn(`${actor.name} doesn't have the ${skillName} skill.`);
      return false;
    }

    // Find this actor's token on the current scene
    const token = canvas.tokens.placeables.find(t => t.actor?.id === actorId);
    if (!token) {
      ui.notifications.warn(`No token for ${actor.name} found on this scene.`);
      return false;
    }

    // Control the token so rollItemMacro can find it, then roll
    token.control({ releaseOthers: true });
    game.cpr.macro.rollItemMacro(skillName, { skipPrompt: false });
    return true;
  } catch (err) {
    console.warn(`[${MODULE_ID}] rollItemMacro threw:`, err);
    return false;
  }
}

/* ============================================================
   ACTOR HELPERS
   ============================================================ */

/**
 * Returns the prototype token image for an actor, falling back to
 * the actor portrait if no prototype token image is set.
 * @param {Actor} actor
 * @returns {string}
 */
function getActorTokenImg(actor) {
  return actor.prototypeToken?.texture?.src
    ?? actor.img
    ?? "icons/svg/mystery-man.svg";
}

/**
 * Returns all player-owned character actors, sorted by name.
 * Includes any actor with a player owner (not just assigned characters)
 * so GMs can target party-adjacent actors too.
 * @returns {Actor[]}
 */
function getPlayerActors() {
  const seen = new Set();
  const actors = [];

  // First: actors assigned to a player as their character
  for (const user of game.users) {
    if (user.isGM || !user.character) continue;
    if (seen.has(user.character.id)) continue;
    seen.add(user.character.id);
    actors.push(user.character);
  }

  // Second: any other character-type actors with a player owner
  for (const actor of game.actors) {
    if (actor.type !== "character") continue;
    if (seen.has(actor.id)) continue;
    if (!actor.hasPlayerOwner) continue;
    seen.add(actor.id);
    actors.push(actor);
  }

  return actors.sort((a, b) => a.name.localeCompare(b.name));
}

/**
 * Returns all unique skill names across the given actors, sorted.
 * @param {Actor[]} actors
 * @returns {string[]}
 */
function getSkillNames(actors) {
  const names = new Set();
  for (const actor of actors) {
    for (const item of actor.items) {
      if (item.type === "skill") names.add(item.name);
    }
  }
  return Array.from(names).sort((a, b) => a.localeCompare(b));
}

/* ============================================================
   GM DIALOG
   ============================================================ */

/**
 * Opens the GM skill request dialog.
 * Skill field is searchable. DV and flavor are optional.
 * Targets default to all player actors.
 * Whisper/public toggle controls chat visibility.
 */
class SkillRequestDialog extends Application {
  constructor(actors, skillNames, options = {}) {
    super(options);
    this.actors = actors;
    this.skillNames = skillNames;
    this.selectedSkill = "";
    this.selectedActorIds = new Set(); // starts empty — deselected
    this.whisper = false;
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "cpr-skill-request-dialog",
      title: "Request Skill Check",
      template: null,
      width: 360,
      height: "auto",
      resizable: false
    });
  }

  get template() { return null; }

  async _renderInner() {
    const dropdownItemsHtml = this.skillNames.map(name =>
      `<div class="cpr-sr-dropdown-item" data-skill="${name}">${name}</div>`
    ).join("");

    const galleryHtml = this.actors.map(actor => {
      const selected = this.selectedActorIds.has(actor.id);
      return `
        <div class="cpr-sr-gallery-item ${selected ? 'selected' : ''}"
             data-actor-id="${actor.id}"
             title="${actor.name}"
             style="
               display:flex;
               flex-direction:column;
               align-items:center;
               gap:4px;
               cursor:pointer;
               padding:4px;
               border-radius:6px;
               border:2px solid ${selected ? '#e07b00' : 'transparent'};
               transition:border-color 0.15s;
             ">
          <img src="${getActorTokenImg(actor)}"
               style="width:60px;height:60px;border-radius:50%;object-fit:cover;display:block;">
          <span style="
            font-size:0.7em;
            text-align:center;
            line-height:1.2;
            max-width:70px;
            overflow:hidden;
            text-overflow:ellipsis;
            white-space:nowrap;
            display:block;
          ">${actor.name.split(" ")[0]}</span>
        </div>`;
    }).join("");

    const html = `
      <div class="cpr-sr-dialog" style="display:flex;flex-direction:column;gap:12px;padding:8px 4px;">

        <div class="cpr-sr-field">
          <label style="font-size:0.82em;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px;opacity:0.7;display:block;margin-bottom:4px;">Skill</label>
          <div class="cpr-sr-search-wrapper" style="position:relative;">
            <input type="text"
                   class="cpr-sr-search-input"
                   id="cpr-sr-skill-input"
                   placeholder="Search skills..."
                   autocomplete="off"
                   style="width:100%;padding:6px 10px;border-radius:3px;font:inherit;font-size:0.9em;box-sizing:border-box;">
            <div class="cpr-sr-dropdown" id="cpr-sr-dropdown" style="position:absolute;top:100%;left:0;right:0;max-height:200px;overflow-y:auto;z-index:1000;border-radius:0 0 3px 3px;display:none;background:var(--color-bg,#1a1a1a);border:1px solid var(--color-border-dark,#444);">
              ${dropdownItemsHtml}
            </div>
          </div>
          <div id="cpr-sr-skill-error" style="color:#e07b00;font-size:0.78em;margin-top:3px;display:none;">
            <i class="fas fa-exclamation-triangle"></i> Please select a skill from the list.
          </div>
        </div>

        <div style="display:flex;gap:12px;">
          <div class="cpr-sr-field" style="flex:0 0 auto;">
            <label style="font-size:0.82em;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px;opacity:0.7;display:block;margin-bottom:4px;">DV <span style="opacity:0.5;font-weight:normal;">(optional)</span></label>
            <input type="number" id="cpr-sr-dv" placeholder="—" min="1" max="99"
                   style="width:70px;padding:5px 8px;border-radius:3px;font:inherit;font-size:0.9em;">
          </div>
          <div class="cpr-sr-field" style="flex:1;">
            <label style="font-size:0.82em;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px;opacity:0.7;display:block;margin-bottom:4px;">Flavor Text <span style="opacity:0.5;font-weight:normal;">(optional)</span></label>
            <input type="text" id="cpr-sr-flavor" placeholder="Make a [Skill] check" autocomplete="off"
                   style="width:100%;padding:5px 8px;border-radius:3px;font:inherit;font-size:0.9em;box-sizing:border-box;">
          </div>
        </div>

        <div class="cpr-sr-field">
          <label style="font-size:0.82em;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px;opacity:0.7;display:block;margin-bottom:6px;">Targets</label>
          <div id="cpr-sr-gallery" style="
            display:grid;
            grid-template-columns:repeat(3,1fr);
            gap:6px;
            margin-bottom:6px;
          ">
            ${galleryHtml}
          </div>
          <div id="cpr-sr-target-error" style="color:#e07b00;font-size:0.78em;margin-bottom:4px;display:none;">
            <i class="fas fa-exclamation-triangle"></i> Select at least one target.
          </div>
          <button id="cpr-sr-select-all" style="
            width:100%;
            padding:5px;
            border-radius:3px;
            font-size:0.82em;
            font-weight:bold;
            cursor:pointer;
            border:1px solid rgba(255,255,255,0.15);
            background:rgba(255,255,255,0.05);
            color:inherit;
            letter-spacing:0.5px;
          ">Select / Deselect All</button>
        </div>

        <div class="cpr-sr-field">
          <label style="font-size:0.82em;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px;opacity:0.7;display:block;margin-bottom:4px;">Visibility</label>
          <div style="display:flex;gap:6px;">
            <div class="cpr-sr-vis-btn active" data-mode="public" style="flex:1;padding:5px;border-radius:3px;font-size:0.82em;font-weight:bold;cursor:pointer;border:1px solid rgba(255,255,255,0.4);background:rgba(255,255,255,0.18);color:inherit;text-align:center;letter-spacing:0.5px;">
              <i class="fas fa-globe"></i> Public
            </div>
            <div class="cpr-sr-vis-btn" data-mode="whisper" style="flex:1;padding:5px;border-radius:3px;font-size:0.82em;font-weight:bold;cursor:pointer;border:1px solid rgba(255,255,255,0.15);background:rgba(255,255,255,0.05);color:inherit;text-align:center;letter-spacing:0.5px;">
              <i class="fas fa-user-secret"></i> Whisper
            </div>
          </div>
        </div>

        <div style="display:flex;gap:8px;padding-top:4px;border-top:1px solid rgba(255,255,255,0.08);">
          <button id="cpr-sr-cancel" style="flex:1;padding:7px;border-radius:4px;font-weight:bold;font-size:0.85em;cursor:pointer;border:1px solid rgba(255,255,255,0.15);background:rgba(255,255,255,0.05);color:inherit;">
            Cancel
          </button>
          <button id="cpr-sr-post" style="flex:2;padding:7px;border-radius:4px;font-weight:bold;font-size:0.85em;cursor:pointer;border:none;background:#e07b00;color:#fff;letter-spacing:0.5px;">
            <i class="fas fa-paper-plane"></i> Post to Chat
          </button>
        </div>

      </div>`;

    return $(`<div>${html}</div>`);
  }

  activateListeners(html) {
    super.activateListeners(html);
    const self = this;

    const skillInput = html.find("#cpr-sr-skill-input");
    const dropdown = html.find("#cpr-sr-dropdown");
    const skillError = html.find("#cpr-sr-skill-error");
    const targetError = html.find("#cpr-sr-target-error");

    // Skill search
    skillInput.on("focus", () => dropdown.css("display", "block"));
    $(document).on("click.cpr-sr-dialog", (e) => {
      if (!$(e.target).closest(".cpr-sr-search-wrapper").length) {
        dropdown.css("display", "none");
      }
    });
    skillInput.on("input", () => {
      const search = skillInput.val().toLowerCase();
      self.selectedSkill = "";
      skillError.hide();
      dropdown.find(".cpr-sr-dropdown-item").each((_, el) => {
        $(el).toggle($(el).data("skill").toLowerCase().includes(search));
      });
      dropdown.css("display", "block");
    });
    dropdown.on("click", ".cpr-sr-dropdown-item", (e) => {
      self.selectedSkill = $(e.currentTarget).data("skill");
      skillInput.val(self.selectedSkill);
      dropdown.css("display", "none");
      skillError.hide();
    });

    // Gallery token selection
    html.on("click", ".cpr-sr-gallery-item", (e) => {
      const $item = $(e.currentTarget);
      const actorId = $item.data("actor-id");
      if (self.selectedActorIds.has(actorId)) {
        self.selectedActorIds.delete(actorId);
        $item.css("border-color", "transparent").removeClass("selected");
      } else {
        self.selectedActorIds.add(actorId);
        $item.css("border-color", "#e07b00").addClass("selected");
      }
      targetError.hide();
    });

    // Select/Deselect All
    html.find("#cpr-sr-select-all").on("click", () => {
      const allSelected = self.actors.every(a => self.selectedActorIds.has(a.id));
      if (allSelected) {
        self.selectedActorIds.clear();
        html.find(".cpr-sr-gallery-item").css("border-color", "transparent").removeClass("selected");
      } else {
        self.actors.forEach(a => self.selectedActorIds.add(a.id));
        html.find(".cpr-sr-gallery-item").css("border-color", "#e07b00").addClass("selected");
      }
      targetError.hide();
    });

    // Visibility toggle
    html.on("click", ".cpr-sr-vis-btn", (e) => {
      const $btn = $(e.currentTarget);
      html.find(".cpr-sr-vis-btn").css({
        "border-color": "rgba(255,255,255,0.15)",
        "background": "rgba(255,255,255,0.05)"
      });
      $btn.css({
        "border-color": "rgba(255,255,255,0.4)",
        "background": "rgba(255,255,255,0.18)"
      });
      self.whisper = $btn.data("mode") === "whisper";
    });

    // Cancel
    html.find("#cpr-sr-cancel").on("click", () => this.close());

    // Post
    html.find("#cpr-sr-post").on("click", () => {
      let valid = true;

      // Validate skill
      if (!self.selectedSkill || !self.skillNames.includes(self.selectedSkill)) {
        skillError.show();
        skillInput.focus();
        valid = false;
      }

      // Validate targets
      if (self.selectedActorIds.size === 0) {
        targetError.show();
        valid = false;
      }

      if (!valid) return; // keep dialog open

      const dvRaw = html.find("#cpr-sr-dv").val().trim();
      const dv = dvRaw !== "" ? parseInt(dvRaw) : null;
      const flavorRaw = html.find("#cpr-sr-flavor").val().trim();
      const flavor = flavorRaw || `Make a ${self.selectedSkill} check`;

      postSkillRequest({
        skillName: self.selectedSkill,
        dv,
        flavor,
        actorIds: Array.from(self.selectedActorIds),
        whisper: self.whisper
      });

      this.close();
    });
  }

  async close(options = {}) {
    $(document).off("click.cpr-sr-dialog");
    return super.close(options);
  }
}

function openRequestDialog() {
  const actors = getPlayerActors();
  const skillNames = getSkillNames(actors);

  if (actors.length === 0) {
    ui.notifications.warn("No player-owned character actors found.");
    return;
  }
  if (skillNames.length === 0) {
    ui.notifications.warn("No skills found on player characters.");
    return;
  }

  // Close existing instance if open
  const existing = Object.values(ui.windows).find(w => w.id === "cpr-skill-request-dialog");
  if (existing) { existing.bringToTop(); return; }

  new SkillRequestDialog(actors, skillNames).render(true);
}

/* ============================================================
   CHAT CARD
   ============================================================ */

/**
 * Builds the chat card HTML for a skill request.
 * Uses CPR's own rollcard classes so the active theme styles it
 * automatically — no hardcoded colors needed.
 *
 * @param {object} params
 * @param {string} params.skillName
 * @param {number|null} params.dv
 * @param {string} params.flavor
 * @param {Array<{id:string, name:string, img:string}>} params.actorSnapshots
 * @param {string} params.requestId
 * @param {object} params.rolledState - Map of actorId → boolean (rolled or not)
 */
function buildCardHtml({ skillName, dv, flavor, actorSnapshots, requestId, rolledState = {} }) {

  const rowsHtml = actorSnapshots.map(actor => {
    const rolled = rolledState[actor.id] ?? false;

    const btnStyle = [
      "display:inline-block",
      "margin-top:4px",
      "padding:4px 16px",
      "border-radius:3px",
      "font-weight:bold",
      "font-size:0.82em",
      "cursor:pointer",
      "border:1px solid rgba(255,255,255,0.25)",
      "background:rgba(255,255,255,0.1)",
      "color:inherit",
      "letter-spacing:0.5px",
      rolled ? "opacity:0.5;font-style:italic" : ""
    ].filter(Boolean).join(";");

    const btnHtml = rolled
      ? `<button
           style="${btnStyle}"
           class="cpr-sr-roll-btn cpr-sr-rolled"
           data-actor-id="${actor.id}"
           data-skill="${skillName}"
           data-request-id="${requestId}">
           <i class="fas fa-check"></i> Roll initiated
         </button>`
      : `<button
           style="${btnStyle}"
           class="cpr-sr-roll-btn"
           data-actor-id="${actor.id}"
           data-skill="${skillName}"
           data-request-id="${requestId}">
           <i class="fas fa-dice-d10"></i> Roll
         </button>`;

    return `
      <div
        class="cpr-sr-row"
        data-actor-id="${actor.id}"
        style="
          display:block;
          text-align:center;
          padding:8px 4px;
          border-top:1px solid rgba(255,255,255,0.08);
          box-sizing:border-box;
          width:100%;
        "
      >
        <img
          src="${actor.img}"
          alt="${actor.name}"
          title="${actor.name}"
          style="
            display:block;
            margin:0 auto 4px;
            width:56px;
            height:56px;
            border-radius:50%;
            object-fit:cover;
            box-shadow:0 0 0 2px rgba(255,255,255,0.2);
          "
        >
        <div style="
          font-weight:bold;
          font-size:0.9em;
          text-align:center;
          margin-bottom:2px;
          overflow:hidden;
          text-overflow:ellipsis;
          white-space:nowrap;
          padding:0 8px;
        ">${actor.name}</div>
        <div style="text-align:center;">
          ${btnHtml}
        </div>
      </div>`;
  }).join("");

  // First row has no top border
  const participantsHtml = rowsHtml.replace(
    'border-top:1px solid rgba(255,255,255,0.08)',
    'border-top:none'
  );

  return `
    <div
      data-request-id="${requestId}"
      style="display:block;width:100%;box-sizing:border-box;"
    >
      ${participantsHtml}
    </div>`;
}

/**
 * Posts the skill request card to chat.
 *
 * @param {object} params
 * @param {string} params.skillName
 * @param {number|null} params.dv
 * @param {string} params.flavor
 * @param {string[]} params.actorIds
 * @param {boolean} params.whisper
 */
async function postSkillRequest({ skillName, dv, flavor, actorIds, whisper }) {
  const requestId = foundry.utils.randomID();

  // Snapshot actor data so the card stays correct even if actors are renamed
  const actorSnapshots = actorIds
    .map(id => game.actors.get(id))
    .filter(Boolean)
    .map(actor => ({
      id: actor.id,
      name: actor.name,
      img: getActorTokenImg(actor)
    }));

  if (actorSnapshots.length === 0) {
    ui.notifications.warn("No valid actors found for skill request.");
    return;
  }

  const content = buildCardHtml({
    skillName,
    dv,
    flavor,
    actorSnapshots,
    requestId,
    rolledState: {}
  });

  // Build whisper recipient list: all targeted players + all GMs
  let whisperTo = [];
  if (whisper) {
    const gmIds = game.users.filter(u => u.isGM).map(u => u.id);
    const playerIds = actorIds.flatMap(actorId => {
      return game.users
        .filter(u => !u.isGM && (
          u.character?.id === actorId ||
          game.actors.get(actorId)?.testUserPermission(u, "OWNER")
        ))
        .map(u => u.id);
    });
    whisperTo = [...new Set([...gmIds, ...playerIds])];
  }

  // Build flavor line — skill name + DV if set
  const flavorLine = dv != null
    ? `<strong>${skillName}</strong> — DV ${dv} · ${flavor}`
    : `<strong>${skillName}</strong> · ${flavor}`;

  await ChatMessage.create({
    content,
    flavor: flavorLine,
    speaker: { alias: "Skill Request" },
    whisper: whisperTo,
    flags: {
      [MODULE_ID]: {
        type: "skillRequest",
        requestId,
        skillName,
        dv: dv ?? null,
        flavor,
        actorSnapshots,
        rolledState: {},
        whisper,
        whisperTo
      }
    }
  });
}

/* ============================================================
   BUTTON HANDLING — renderChatMessage hook
   ============================================================ */

/**
 * Controls per-user button visibility and wires up click handlers
 * for every rendered skill request card.
 *
 * Visibility rules:
 *   - GM: sees ALL rows and buttons
 *   - Player: sees ALL rows (social — everyone knows who else is being asked)
 *     but can only CLICK their own button. Other rows show as "waiting" or
 *     "rolled" read-only.
 */
Hooks.on("renderChatMessage", (message, html) => {
  const data = message.flags?.[MODULE_ID];
  if (data?.type !== "skillRequest") return;

  const { skillName, actorSnapshots, rolledState = {}, requestId } = data;
  const isGM = game.user.isGM;

  // Find which actor(s) belong to this user
  const myActorIds = new Set(
    actorSnapshots
      .filter(snap => {
        const actor = game.actors.get(snap.id);
        if (!actor) return false;
        return game.user.character?.id === snap.id
          || actor.testUserPermission(game.user, "OWNER");
      })
      .map(snap => snap.id)
  );

  // Process each participant row
  html.find(".cpr-sr-row, [data-actor-id]").each((_, rowEl) => {
    const $row = $(rowEl);
    const actorId = $row.data("actor-id");
    const isMyActor = myActorIds.has(actorId);
    const hasRolled = rolledState[actorId] ?? false;

    if (isGM) {
      _wireButton($row, actorId, skillName, requestId, hasRolled, message, data, true);
    } else if (isMyActor) {
      _wireButton($row, actorId, skillName, requestId, hasRolled, message, data, false);
    } else {
      // Other player's row — replace button with read-only status
      const $btn = $row.find(".cpr-sr-roll-btn");
      if (hasRolled) {
        $btn.replaceWith(`<span style="font-size:0.78em;opacity:0.45;font-style:italic;"><i class="fas fa-check"></i> Rolled</span>`);
      } else {
        $btn.replaceWith(`<span style="font-size:0.78em;opacity:0.45;font-style:italic;">Waiting...</span>`);
      }
    }
  });
});

/**
 * Wires up click behavior for a roll button slot.
 *
 * @param {jQuery} $btnSlot - The container for the button
 * @param {string} actorId
 * @param {string} skillName
 * @param {string} requestId
 * @param {boolean} hasRolled - Current rolled state
 * @param {ChatMessage} message
 * @param {object} flagData - Full flag data from the message
 * @param {boolean} isGM
 */
function _wireButton($row, actorId, skillName, requestId, hasRolled, message, flagData, isGM) {
  const $btn = $row.find(".cpr-sr-roll-btn");
  if (!$btn.length) return;

  $btn.on("click", async (e) => {
    e.preventDefault();

    if (hasRolled) {
      // Confirm re-roll
      const confirm = await Dialog.confirm({
        title: "Roll Again?",
        content: "<p>You've already rolled! Roll again?</p>",
        yes: () => true,
        no: () => false,
        defaultYes: false
      });
      if (!confirm) return;
    }

    // Fire the roll — only mark as rolled if it succeeded
    const success = executeSkillRoll(skillName, actorId);
    if (success) {
      if (game.user.isGM) {
        // GM can update directly
        await _markRolled(message, flagData, actorId);
      } else {
        // Players ask the GM client to do the update via socketlib
        if (socket) {
          await socket.executeAsGM("markRolled", { messageId: message.id, actorId });
        } else {
          ui.notifications.warn("socketlib is required for players to update roll state.");
        }
      }
    }
  });
}

/**
 * Updates the message flags to mark an actor as rolled, then
 * rebuilds and updates the card HTML to reflect the new state.
 *
 * @param {ChatMessage} message
 * @param {object} flagData
 * @param {string} actorId
 */
async function _markRolled(message, flagData, actorId) {
  const newRolledState = {
    ...(flagData.rolledState ?? {}),
    [actorId]: true
  };

  const newContent = buildCardHtml({
    skillName: flagData.skillName,
    dv: flagData.dv,
    flavor: flagData.flavor,
    actorSnapshots: flagData.actorSnapshots,
    requestId: flagData.requestId,
    rolledState: newRolledState
  });

  await message.update({
    content: newContent,
    flags: {
      [MODULE_ID]: {
        ...flagData,
        rolledState: newRolledState
      }
    }
  });
}

/* ============================================================
   updateChatMessage hook — scroll to bottom after state update
   ============================================================ */

Hooks.on("updateChatMessage", (message) => {
  if (!message.flags?.[MODULE_ID]) return;
  requestAnimationFrame(() => ui.chat?.scrollBottom?.());
});

/* ============================================================
   SOCKETLIB — allows players to ask GM to update the message
   ============================================================ */

let socket;

Hooks.once("socketlib.ready", () => {
  socket = socketlib.registerModule(MODULE_ID);
  socket.register("markRolled", _gmMarkRolled);
  console.log(`[${MODULE_ID}] socketlib registered`);
});

Hooks.once("ready", () => {
  const mod = game.modules.get(MODULE_ID);
  if (!mod) return;
  mod.api = {
    requestSkillCheck: openRequestDialog,
    postSkillRequest,
    executeSkillRoll
  };
  console.log(`[${MODULE_ID}] ready`);
});

/**
 * Runs on the GM client via socketlib.
 * Updates the chat message to mark an actor as rolled.
 */
async function _gmMarkRolled({ messageId, actorId }) {
  const message = game.messages.get(messageId);
  if (!message) return;
  const flagData = message.flags?.[MODULE_ID];
  if (!flagData) return;
  await _markRolled(message, flagData, actorId);
}
