// Theater Curtain — Remote Control
// Opens the persistent floating control panel (drop/raise buttons + status).
// Import this into a macro and run it whenever you want the panel on screen.

game.modules.get("theater-curtain")?.api?.openControlPanel();
