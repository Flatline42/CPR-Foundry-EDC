const MODULE_ID = "theater-curtain";

const DEFAULT_STATE = {
  deployed: false,
  roleThreshold: CONST.USER_ROLES.TRUSTED,
  queue: [],
  queueIndex: 0,
  currentImage: ""
};

const IMAGE_EXTENSIONS = [".png", ".jpg", ".jpeg", ".webp"];
const SWAP_FADE_MS = 600;
const DROP_FADE_MS = 800;

let cycleTimer = null;
let lastKnownState = foundry.utils.deepClone(DEFAULT_STATE);

/* -------------------------------------------- */
/*  Utility                                      */
/* -------------------------------------------- */

function shuffle(array) {
  const arr = array.slice();
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function preload(path) {
  return new Promise((resolve) => {
    if (!path) return resolve();
    const img = new Image();
    img.onload = resolve;
    img.onerror = resolve;
    img.src = path;
  });
}

function isPrimaryGM() {
  return game.user.isGM && game.users.activeGM?.id === game.user.id;
}

/* -------------------------------------------- */
/*  Settings                                     */
/* -------------------------------------------- */

function registerSettings() {
  game.settings.register(MODULE_ID, "imageFolder", {
    scope: "world",
    config: false,
    type: String,
    default: ""
  });

  game.settings.register(MODULE_ID, "cycleInterval", {
    scope: "world",
    config: false,
    type: Number,
    default: 105
  });

  game.settings.register(MODULE_ID, "defaultThreshold", {
    scope: "world",
    config: false,
    type: Number,
    default: CONST.USER_ROLES.TRUSTED
  });

  game.settings.register(MODULE_ID, "logoImage", {
    scope: "world",
    config: false,
    type: String,
    default: ""
  });

  game.settings.register(MODULE_ID, "curtainState", {
    scope: "world",
    config: false,
    type: Object,
    default: foundry.utils.deepClone(DEFAULT_STATE),
    onChange: onCurtainStateChange
  });

  game.settings.registerMenu(MODULE_ID, "configMenu", {
    name: "Theater Curtain Settings",
    label: "Configure Theater Curtain",
    hint: "Set the image folder, cycle interval, default player threshold, and logo image.",
    icon: "fas fa-theater-masks",
    type: TheaterCurtainConfig,
    restricted: true
  });
}

/* -------------------------------------------- */
/*  Settings Form (GM only via restricted menu)  */
/* -------------------------------------------- */

class TheaterCurtainConfig extends FormApplication {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "theater-curtain-config",
      title: "Theater Curtain Settings",
      template: `modules/${MODULE_ID}/templates/theater-curtain-config.hbs`,
      width: 480,
      closeOnSubmit: true
    });
  }

  getData() {
    return {
      imageFolder: game.settings.get(MODULE_ID, "imageFolder"),
      cycleInterval: game.settings.get(MODULE_ID, "cycleInterval"),
      defaultThreshold: game.settings.get(MODULE_ID, "defaultThreshold"),
      logoImage: game.settings.get(MODULE_ID, "logoImage"),
      roleOptions: {
        [CONST.USER_ROLES.PLAYER]: "Player",
        [CONST.USER_ROLES.TRUSTED]: "Trusted Player",
        [CONST.USER_ROLES.ASSISTANT]: "Assistant GM",
        [CONST.USER_ROLES.GAMEMASTER]: "Gamemaster"
      }
    };
  }

  activateListeners(html) {
    super.activateListeners(html);
    html.find(".tc-file-picker").on("click", (event) => {
      const button = event.currentTarget;
      const targetName = button.dataset.target;
      const input = html.find(`input[name="${targetName}"]`)[0];
      const fp = new FilePicker({
        type: button.dataset.type,
        current: input.value,
        callback: (path) => {
          input.value = path;
        }
      });
      fp.render(true);
    });
  }

  async _updateObject(event, formData) {
    await game.settings.set(MODULE_ID, "imageFolder", formData.imageFolder);
    await game.settings.set(MODULE_ID, "cycleInterval", Math.max(5, Number(formData.cycleInterval) || 105));
    await game.settings.set(MODULE_ID, "defaultThreshold", Number(formData.defaultThreshold));
    await game.settings.set(MODULE_ID, "logoImage", formData.logoImage);
  }
}

/* -------------------------------------------- */
/*  Overlay DOM                                  */
/* -------------------------------------------- */

function ensureOverlay() {
  if (document.getElementById("theater-curtain-overlay")) return;

  const overlay = document.createElement("div");
  overlay.id = "theater-curtain-overlay";

  const backdrop = document.createElement("div");
  backdrop.id = "theater-curtain-backdrop";
  overlay.appendChild(backdrop);

  const shade = document.createElement("div");
  shade.id = "theater-curtain-shade";
  overlay.appendChild(shade);

  const logo = document.createElement("img");
  logo.id = "theater-curtain-logo";
  const logoPath = game.settings.get(MODULE_ID, "logoImage");
  if (logoPath) logo.src = logoPath;
  overlay.appendChild(logo);

  document.body.appendChild(overlay);
}

function setBackdrop(path) {
  const el = document.getElementById("theater-curtain-backdrop");
  if (!el) return;
  el.style.backgroundImage = path ? `url("${path}")` : "";
}

function showCurtain(imagePath) {
  ensureOverlay();
  setBackdrop(imagePath);
  document.getElementById("theater-curtain-overlay")?.classList.add("visible");
}

function hideCurtain() {
  document.getElementById("theater-curtain-overlay")?.classList.remove("visible");
}

async function swapBackdrop(path) {
  const shade = document.getElementById("theater-curtain-shade");
  if (!shade) {
    setBackdrop(path);
    return;
  }
  shade.classList.add("active");
  await wait(SWAP_FADE_MS);
  await preload(path);
  setBackdrop(path);
  shade.classList.remove("active");
}

/* -------------------------------------------- */
/*  Reactive state application (every client)    */
/* -------------------------------------------- */

function onCurtainStateChange(newState) {
  const wasVisibleToMe = lastKnownState.deployed && game.user.role <= lastKnownState.roleThreshold;
  const isVisibleToMe = newState.deployed && game.user.role <= newState.roleThreshold;
  const imageChanged = newState.currentImage !== lastKnownState.currentImage;

  if (!wasVisibleToMe && isVisibleToMe) {
    showCurtain(newState.currentImage);
  } else if (wasVisibleToMe && !isVisibleToMe) {
    hideCurtain();
  } else if (wasVisibleToMe && isVisibleToMe && imageChanged) {
    swapBackdrop(newState.currentImage);
  }

  lastKnownState = foundry.utils.deepClone(newState);

  // Keep the control panel's status line current if it's open.
  const panel = Object.values(ui.windows).find((w) => w.id === "theater-curtain-control-panel");
  panel?.render();
}

/* -------------------------------------------- */
/*  Queue / cycling (GM-driven, activeGM only)   */
/* -------------------------------------------- */

async function buildQueue() {
  const folder = game.settings.get(MODULE_ID, "imageFolder");
  if (!folder) {
    ui.notifications.warn("Theater Curtain: no image folder configured. Set one in module settings.");
    return [];
  }
  let browse;
  try {
    browse = await FilePicker.browse("data", folder);
  } catch (err) {
    ui.notifications.error("Theater Curtain: could not read the configured image folder.");
    return [];
  }
  const files = browse.files.filter((f) =>
    IMAGE_EXTENSIONS.some((ext) => f.toLowerCase().endsWith(ext))
  );
  if (!files.length) {
    ui.notifications.warn("Theater Curtain: no images found in the configured folder.");
  }
  return shuffle(files);
}

function startCycleTimer() {
  stopCycleTimer();
  const seconds = game.settings.get(MODULE_ID, "cycleInterval");
  cycleTimer = setInterval(advanceImage, seconds * 1000);
}

function stopCycleTimer() {
  if (cycleTimer) clearInterval(cycleTimer);
  cycleTimer = null;
}

async function advanceImage() {
  if (!isPrimaryGM()) return;
  const state = foundry.utils.deepClone(game.settings.get(MODULE_ID, "curtainState"));
  if (!state.deployed || !state.queue.length) return;

  let { queue, queueIndex } = state;
  queueIndex++;
  if (queueIndex >= queue.length) {
    queue = shuffle(queue);
    queueIndex = 0;
  }

  state.queue = queue;
  state.queueIndex = queueIndex;
  state.currentImage = queue[queueIndex];
  await game.settings.set(MODULE_ID, "curtainState", state);
}

/* -------------------------------------------- */
/*  Public actions (called from control panel)   */
/* -------------------------------------------- */

async function dropCurtain(roleThreshold) {
  if (!isPrimaryGM()) {
    ui.notifications.warn("Only the active GM can control the curtain.");
    return;
  }
  const queue = await buildQueue();
  if (!queue.length) return;

  const state = {
    deployed: true,
    roleThreshold,
    queue,
    queueIndex: 0,
    currentImage: queue[0]
  };
  await game.settings.set(MODULE_ID, "curtainState", state);
  startCycleTimer();
}

async function raiseCurtain() {
  if (!isPrimaryGM()) {
    ui.notifications.warn("Only the active GM can control the curtain.");
    return;
  }
  stopCycleTimer();
  await game.settings.set(MODULE_ID, "curtainState", foundry.utils.deepClone(DEFAULT_STATE));
}

/* -------------------------------------------- */
/*  GM Control Panel                             */
/* -------------------------------------------- */

class TheaterCurtainControlPanel extends Application {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "theater-curtain-control-panel",
      title: "Theater Curtain",
      template: `modules/${MODULE_ID}/templates/control-panel.hbs`,
      width: 260,
      height: "auto",
      resizable: false,
      popOut: true
    });
  }

  getData() {
    const state = game.settings.get(MODULE_ID, "curtainState");
    return { deployed: state.deployed };
  }

  activateListeners(html) {
    super.activateListeners(html);
    html.find('[data-action="drop-players"]').on("click", async () => {
      const threshold = game.settings.get(MODULE_ID, "defaultThreshold");
      await dropCurtain(threshold);
      this.render();
    });
    html.find('[data-action="drop-everyone"]').on("click", async () => {
      await dropCurtain(CONST.USER_ROLES.GAMEMASTER);
      this.render();
    });
    html.find('[data-action="raise"]').on("click", async () => {
      await raiseCurtain();
      this.render();
    });
  }
}

/* -------------------------------------------- */
/*  Hooks                                        */
/* -------------------------------------------- */

Hooks.once("init", () => {
  registerSettings();
});

Hooks.once("ready", () => {
  ensureOverlay();

  const state = game.settings.get(MODULE_ID, "curtainState");
  lastKnownState = foundry.utils.deepClone(DEFAULT_STATE);
  onCurtainStateChange(state);

  if (isPrimaryGM() && state.deployed) {
    startCycleTimer();
  }

  game.modules.get(MODULE_ID).api = {
    openControlPanel: () => new TheaterCurtainControlPanel().render(true),
    dropCurtain,
    raiseCurtain
  };
});
