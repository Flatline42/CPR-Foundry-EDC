import { generateLibraryCSS } from "./css-generator.js";
import { CprThemeDesignerApp } from "./theme-designer-app.js";

const MODULE_ID = "cpr-theme-designer";

/**
 * Maps our setting's stored string values to Foundry's numeric
 * CONST.USER_ROLES levels. Descending access order: a user's role
 * level must be >= the configured minimum to use the designer.
 */
const ROLE_LEVELS = {
  GAMEMASTER: CONST.USER_ROLES.GAMEMASTER,
  ASSISTANT: CONST.USER_ROLES.ASSISTANT,
  TRUSTED: CONST.USER_ROLES.TRUSTED,
  PLAYER: CONST.USER_ROLES.PLAYER,
};

/**
 * Checks the current user's role against the GM-configured minimum.
 * Exported on the game namespace (see below) so the app itself can
 * gate access too — hiding the settings-menu button alone isn't
 * enough, since the app can also be opened via macro.
 */
function hasThemeDesignerAccess() {
  const minRole = game.settings.get(MODULE_ID, "minAccessRole") || "GAMEMASTER";
  const required = ROLE_LEVELS[minRole] ?? ROLE_LEVELS.GAMEMASTER;
  return game.user.role >= required;
}

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "themeLibrary", {
    scope: "world",
    config: false,
    type: Array,
    default: [],
  });

  // GM-only setting (restricted: true hides the field from non-GM
  // users in Configure Settings, but the value itself is still
  // readable by every client via game.settings.get — that's how we
  // gate access for non-GM roles below).
  game.settings.register(MODULE_ID, "minAccessRole", {
    name: "Minimum Role to Use Theme Designer",
    hint: "Who can open the CPR Theme Designer. Descending order — Assistant and above also covers Game Master, etc.",
    scope: "world",
    config: true,
    restricted: true,
    type: String,
    choices: {
      GAMEMASTER: "Game Master",
      ASSISTANT: "Assistant GM",
      TRUSTED: "Trusted Player",
      PLAYER: "Player",
    },
    default: "GAMEMASTER",
  });

  // registerMenu's own "restricted" flag is a binary GM/non-GM switch —
  // too coarse for graduated roles, so it's left false here and access
  // is gated ourselves via hasThemeDesignerAccess(), both on the button
  // (renderSettingsConfig hook below) and inside the app's render().
  game.settings.registerMenu(MODULE_ID, "themeDesignerMenu", {
    name: "CPR Theme Designer",
    label: "Open Theme Designer",
    hint: "Build, save, and manage custom color themes for Cyberpunk RED.",
    icon: "fas fa-palette",
    type: CprThemeDesignerApp,
    restricted: false,
  });

  // Register one cprcThemes entry per saved library palette.
  // NOTE: cprcThemes registration only happens here, at init. Themes
  // saved/edited after this point won't appear in CPR's dropdown until
  // a Foundry reload (F5). See Theme_Designer.md Section 3.
  const library = game.settings.get(MODULE_ID, "themeLibrary") || [];
  const cprcThemes = {};
  library.forEach((entry) => {
    cprcThemes[entry.id] = entry.name;
  });
  game.modules.get(MODULE_ID).cprcThemes = cprcThemes;

  // Convenience handle for launching via macro/console without needing
  // to navigate settings menus — see README/macro for usage. Also
  // exposes the access-check function so the app can gate itself.
  game.cprThemeDesigner = {
    App: CprThemeDesignerApp,
    MODULE_ID,
    hasAccess: hasThemeDesignerAccess,
  };
});

// Hide the settings-menu button entirely for users below the
// configured minimum role, so it doesn't even appear as a dead end.
Hooks.on("renderSettingsConfig", (app, html) => {
  if (hasThemeDesignerAccess()) return;
  html.find(`button[data-key="${MODULE_ID}.themeDesignerMenu"]`)
    .closest(".form-group")
    .remove();
});

Hooks.once("ready", () => {
  const library = game.settings.get(MODULE_ID, "themeLibrary") || [];
  if (!library.length) return;

  const css = generateLibraryCSS(library);
  let styleEl = document.getElementById("cpr-theme-designer-injected");
  if (!styleEl) {
    styleEl = document.createElement("style");
    styleEl.id = "cpr-theme-designer-injected";
    document.head.appendChild(styleEl);
  }
  styleEl.textContent = css;
});
