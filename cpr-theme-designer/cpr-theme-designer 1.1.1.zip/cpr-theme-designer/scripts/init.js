import { generateLibraryCSS } from "./css-generator.js";
import { CprThemeDesignerApp } from "./theme-designer-app.js";

const MODULE_ID = "cpr-theme-designer";

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "themeLibrary", {
    scope: "world",
    config: false,
    type: Array,
    default: [],
  });

  // Proper Foundry settings-menu registration — creates its own
  // section heading automatically, no manual DOM injection needed.
  // (Superseded the earlier renderSettings-hook approach, which placed
  // the button in an arbitrary spot at the top of the sidebar.)
  game.settings.registerMenu(MODULE_ID, "themeDesignerMenu", {
    name: "CPR Theme Designer",
    label: "Open Theme Designer",
    hint: "Build, save, and manage custom color themes for Cyberpunk RED.",
    icon: "fas fa-palette",
    type: CprThemeDesignerApp,
    restricted: true,
  });

  // Register one cprcThemes entry per saved library palette.
  // NOTE: cprcThemes registration only happens here, at init. Themes
  // saved/edited after this point won't appear in CPR's dropdown until
  // a Foundry reload (F5). See Theme_Designer.md Section 3.
  const library = game.settings.get(MODULE_ID, "themeLibrary") || [];
  const cprcThemes = {};
  library.forEach((entry) => {
    cprcThemes[entry.id] = entry.name;
  });
  game.modules.get(MODULE_ID).cprcThemes = cprcThemes;

  // Convenience handle for launching via macro/console without needing
  // to navigate settings menus — see README/macro for usage.
  game.cprThemeDesigner = { App: CprThemeDesignerApp, MODULE_ID };
});

Hooks.once("ready", () => {
  const library = game.settings.get(MODULE_ID, "themeLibrary") || [];
  if (!library.length) return;

  const css = generateLibraryCSS(library);
  let styleEl = document.getElementById("cpr-theme-designer-injected");
  if (!styleEl) {
    styleEl = document.createElement("style");
    styleEl.id = "cpr-theme-designer-injected";
    document.head.appendChild(styleEl);
  }
  styleEl.textContent = css;
});
