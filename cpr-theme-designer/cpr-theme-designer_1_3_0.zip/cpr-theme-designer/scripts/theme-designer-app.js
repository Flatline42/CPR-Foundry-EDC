import {
  generateSuggestions,
  generateThemeCSS,
  generatePreviewCSS,
  DEFAULT_MODE,
  ROW_ORDER,
} from "./css-generator.js";

const PREVIEW_SELECTOR = "#cpr-theme-designer-app .ctd-preview-live";

const ROW_LABELS = {
  background: "Background",
  header: "Header",
  structural: "Structural / Borders",
  accent: "Primary Accent",
  text: "Body Text",
  secondary: "Secondary Highlight",
  inputBg: "Input Field BG",
  rowEven: "Alternating Row",
};

const DEFAULT_COLORS = {
  background: "#041348",
  header: "#020b2e",
  structural: "#3d43b4",
  accent: "#1afe49",
  text: "#e0e0e0",
  secondary: "#8386f5",
  inputBg: "#0a0908",
  rowEven: "#083e12",
};

const LOREM = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.";

/**
 * CPR Theme Designer — main builder Application.
 *
 * Extends FormApplication (not plain Application) because Foundry v12's
 * game.settings.registerMenu() enforces this at runtime — passing a
 * plain Application subclass throws "You must provide a menu type that
 * is a FormApplication or ApplicationV2 instance or subclass" and
 * silently aborts the entire init hook (including everything after the
 * registerMenu call). We don't use FormApplication's form-submit
 * pipeline — _updateObject() is a required no-op since all
 * save/load/library logic is handled manually via our own listeners.
 *
 * Self-contained HTML (no .hbs template) — same pattern used in the
 * Crew Skill Comparison macro. State lives on the instance; every
 * interaction re-renders the color rows and the scoped preview <style>.
 */
export class CprThemeDesignerApp extends FormApplication {
  constructor(options = {}) {
    super({}, options);

    /** @type {Record<string,string>} current 8 working colors */
    this.colors = { ...DEFAULT_COLORS };
    /** @type {Record<string,string>} per-row mode: "shade" | "hue" */
    this.rowMode = { ...DEFAULT_MODE };
    /** @type {Record<string,number>} per-row selected swatch: 0-2, or -1 for custom */
    this.rowSelection = Object.fromEntries(ROW_ORDER.map((k) => [k, -1]));
    /** @type {string} primary seed used to generate suggestions */
    this.seed = this.colors.accent;
    /** @type {string} currently loaded library entry name, if any */
    this.loadedName = null;
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "cpr-theme-designer-app",
      title: "CPR Theme Designer",
      template: null,
      classes: ["cpr-theme-designer"],
      width: 900,
      height: 720,
      resizable: true,
      scrollY: [".ctd-rows", ".ctd-library-list"],
    });
  }

  get template() { return null; }

  /**
   * Gates access at the app level, not just by hiding the settings
   * button — the app can also be opened via macro
   * (new game.cprThemeDesigner.App().render(true)), so the button
   * being hidden alone wouldn't stop that path.
   */
  async render(force, options) {
    const hasAccess = game.cprThemeDesigner?.hasAccess?.() ?? game.user.isGM;
    if (!hasAccess) {
      ui.notifications.warn("You don't have permission to open the CPR Theme Designer.");
      return this;
    }
    return super.render(force, options);
  }

  /**
   * Required by FormApplication but unused — this tool doesn't submit
   * via Foundry's standard <form> pipeline. All persistence happens
   * through explicit button listeners (_onSave, _onDelete, etc.) that
   * call game.settings.set directly.
   */
  async _updateObject(event, formData) {
    // Intentional no-op.
  }

  // ── Library helpers ─────────────────────────────────────

  getLibrary() {
    return game.settings.get("cpr-theme-designer", "themeLibrary") || [];
  }

  async setLibrary(lib) {
    await game.settings.set("cpr-theme-designer", "themeLibrary", lib);
  }

  // ── Rendering ────────────────────────────────────────────

  async _renderInner() {
    return $(this._buildHTML());
  }

  _buildHTML() {
    return `
      ${this._styleBlock()}
      <div class="ctd-wrapper">
        <div class="ctd-main">
          <div class="ctd-seed-row">
            <label>Seed Color</label>
            <input type="color" id="ctd-seed" value="${this.seed}">
            <input type="text" id="ctd-seed-hex" value="${this.seed}" maxlength="7">
            <button type="button" id="ctd-generate">Generate Suggestions</button>
          </div>
          <div class="ctd-rows">
            ${ROW_ORDER.map((key) => this._buildRow(key)).join("")}
          </div>
          <div class="ctd-save-row">
            <input type="text" id="ctd-theme-name" placeholder="Theme name..." value="${this.loadedName || ""}">
            <button type="button" id="ctd-save">Save to Library</button>
          </div>
          <div class="ctd-reload-note">New/changed themes need a Foundry reload (F5) before they appear in CPR's Theme dropdown.</div>
        </div>
        <div class="ctd-sidebar">
          <div class="ctd-preview-panel">
            <div class="ctd-preview-label-row">
              <span class="ctd-preview-label">Live Preview</span>
              <button type="button" id="ctd-refresh-preview" title="Force-refresh the preview if it looks out of sync">Refresh</button>
            </div>
            <div class="ctd-preview">${this._buildPreviewMockup()}</div>
          </div>
          <div class="ctd-library-panel">
            <div class="ctd-preview-label">Theme Library</div>
            <div class="ctd-library-list">${this._buildLibraryList()}</div>
          </div>
          <div class="ctd-io-panel">
            <button type="button" id="ctd-export">Export JSON</button>
            <button type="button" id="ctd-import-toggle">Import JSON</button>
            <textarea id="ctd-io-textarea" class="hidden" placeholder="Paste theme JSON here..."></textarea>
            <button type="button" id="ctd-import-confirm" class="hidden">Load Into Editor</button>
          </div>
        </div>
      </div>`;
  }

  _buildRow(key) {
    const mode = this.rowMode[key];
    const suggestions = generateSuggestions(key, this.seed, mode);
    const selection = this.rowSelection[key];
    const current = this.colors[key];

    const swatches = suggestions.map((hex, i) => `
      <div class="ctd-swatch-wrap">
        <div class="ctd-swatch ${selection === i ? "selected" : ""}"
             style="background:${hex}"
             data-row="${key}" data-index="${i}" data-hex="${hex}"
             title="Click to select">
        </div>
        <div class="ctd-swatch-hex">${hex}</div>
      </div>
    `).join("");

    return `
      <div class="ctd-row" data-row-key="${key}">
        <div class="ctd-row-header">
          <span class="ctd-row-label">${ROW_LABELS[key]}</span>
          <div class="ctd-mode-switch" data-row="${key}">
            <span class="ctd-mode-switch-label ${mode === "shade" ? "active" : ""}">Shade</span>
            <button type="button" class="ctd-switch-track ${mode === "hue" ? "hue" : ""}" data-row="${key}">
              <span class="ctd-switch-thumb"></span>
            </button>
            <span class="ctd-mode-switch-label ${mode === "hue" ? "active" : ""}">Hue</span>
          </div>
        </div>
        <div class="ctd-swatches">
          ${swatches}
          <div class="ctd-swatch-wrap">
            <input type="color" class="ctd-custom-color ${selection === -1 ? "selected" : ""}" data-row="${key}" value="${current}">
            <div class="ctd-swatch-hex">Custom: ${current}</div>
          </div>
        </div>
      </div>`;
  }

  _buildLibraryList() {
    const lib = this.getLibrary();
    if (!lib.length) return `<div class="ctd-empty">No saved themes yet.</div>`;
    return lib.map((entry) => `
      <div class="ctd-lib-entry" data-id="${entry.id}">
        <div class="ctd-lib-swatches">
          ${ROW_ORDER.map((k) => `<span class="ctd-lib-chip" style="background:${entry.colors[k]}"></span>`).join("")}
        </div>
        <span class="ctd-lib-name">${entry.name}</span>
        <button type="button" class="ctd-lib-load" data-id="${entry.id}">Load</button>
        <button type="button" class="ctd-lib-dup" data-id="${entry.id}">Duplicate</button>
        <button type="button" class="ctd-lib-del" data-id="${entry.id}">Delete</button>
      </div>
    `).join("");
  }

  _buildPreviewMockup() {
    return `
      <div class="ctd-preview-live">
        <nav class="navtabs-right cpr-tabs nav" data-group="primary">
          <div class="tab-pink-underlay">
            <a class="tab-label text-semi tab-indent active">Skills</a>
          </div>
          <div class="tab-pink-underlay">
            <a class="tab-label text-semi tab-indent">Gear</a>
          </div>
          <div class="tab-pink-underlay">
            <a class="tab-label text-semi tab-indent">Cyber</a>
          </div>
        </nav>
        <ol class="left-pane-skills items-list">
          <li class="items-header">Awareness Skills –</li>
          <li class="ctd-preview-row odd">Perception <span>4</span></li>
          <li class="ctd-preview-row even">Concentration <span>3</span></li>
        </ol>
        <div class="ctd-preview-text-block">
          <p class="text-normal">${LOREM}</p>
          <input type="text" class="filter-contents" value="Search skills, gear, etc." readonly>
          <a class="rollable">Rollable Link</a>
        </div>
      </div>
    `;
  }

  _styleBlock() {
    const css = generatePreviewCSS(PREVIEW_SELECTOR, this.colors);
    return `<style id="ctd-preview-style">${css}</style>`;
  }

  // ── Listeners ────────────────────────────────────────────

  activateListeners(html) {
    super.activateListeners(html);

    html.find("#ctd-seed").on("input", (e) => {
      this.seed = e.currentTarget.value;
      html.find("#ctd-seed-hex").val(this.seed);
    });
    html.find("#ctd-seed-hex").on("change", (e) => {
      const val = e.currentTarget.value;
      if (/^#[0-9a-fA-F]{6}$/.test(val)) {
        this.seed = val;
        this.render(false);
      }
    });
    html.find("#ctd-generate").on("click", () => this.render(false));

    html.find(".ctd-switch-track").on("click", (e) => {
      const row = e.currentTarget.dataset.row;
      this.rowMode[row] = this.rowMode[row] === "hue" ? "shade" : "hue";
      this.rowSelection[row] = -1;
      this.render(false);
    });

    html.find(".ctd-swatch").on("click", (e) => {
      const { row, index, hex } = e.currentTarget.dataset;
      this.rowSelection[row] = Number(index);
      this.colors[row] = hex;
      this._refreshPreview(html);
      this.render(false);
    });

    html.find(".ctd-custom-color").on("input change", (e) => {
      const row = e.currentTarget.dataset.row;
      const hex = e.currentTarget.value;
      this.rowSelection[row] = -1;
      this.colors[row] = hex;

      const rowEl = $(e.currentTarget).closest(".ctd-row");
      rowEl.find(".ctd-swatch").removeClass("selected");
      $(e.currentTarget).addClass("selected");
      $(e.currentTarget).siblings(".ctd-swatch-hex").text(`Custom: ${hex}`);

      this._refreshPreview(html);
    });

    html.find("#ctd-refresh-preview").on("click", () => this._refreshPreview(html));

    html.find("#ctd-save").on("click", () => this._onSave(html));

    html.find(".ctd-lib-load").on("click", (e) => this._onLoad(e.currentTarget.dataset.id));
    html.find(".ctd-lib-dup").on("click", (e) => this._onDuplicate(e.currentTarget.dataset.id));
    html.find(".ctd-lib-del").on("click", (e) => this._onDelete(e.currentTarget.dataset.id));

    html.find("#ctd-export").on("click", () => this._onExport(html));
    html.find("#ctd-import-toggle").on("click", () => {
      html.find("#ctd-io-textarea, #ctd-import-confirm").toggleClass("hidden");
    });
    html.find("#ctd-import-confirm").on("click", () => this._onImport(html));
  }

  /** Live-update just the scoped <style> block without a full re-render. */
  _refreshPreview(html) {
    const css = generatePreviewCSS(PREVIEW_SELECTOR, this.colors);
    html.find("#ctd-preview-style").html(css);
  }

  // ── Actions ──────────────────────────────────────────────

  async _onSave(html) {
    const name = html.find("#ctd-theme-name").val().trim();
    if (!name) {
      ui.notifications.warn("Enter a theme name before saving.");
      return;
    }
    const id = name.toLowerCase().replace(/[^a-z0-9]/g, "");
    if (!id) {
      ui.notifications.warn("Theme name must contain at least one letter or number.");
      return;
    }

    const lib = this.getLibrary();
    const existingIndex = lib.findIndex((e) => e.id === id);
    if (existingIndex >= 0) {
      const confirmed = await Dialog.confirm({
        title: "Overwrite Theme?",
        content: `<p>A theme named "<strong>${lib[existingIndex].name}</strong>" already exists. Overwrite it?</p>`,
      });
      if (!confirmed) return;
      lib[existingIndex] = { id, name, colors: { ...this.colors } };
    } else {
      lib.push({ id, name, colors: { ...this.colors } });
    }

    await this.setLibrary(lib);
    this.loadedName = name;
    ui.notifications.info(`Saved "${name}". Reload Foundry (F5) for it to appear in CPR's Theme dropdown.`);
    this.render(false);
  }

  _onLoad(id) {
    const entry = this.getLibrary().find((e) => e.id === id);
    if (!entry) return;
    this.colors = { ...entry.colors };
    this.seed = entry.colors.accent;
    this.loadedName = entry.name;
    Object.keys(this.rowSelection).forEach((k) => { this.rowSelection[k] = -1; });
    this.render(false);
  }

  async _onDuplicate(id) {
    const entry = this.getLibrary().find((e) => e.id === id);
    if (!entry) return;
    const newName = await this._promptText("Duplicate Theme", "New theme name:", `${entry.name} Copy`);
    if (!newName) return;
    const newId = newName.toLowerCase().replace(/[^a-z0-9]/g, "");
    const lib = this.getLibrary();
    if (lib.some((e) => e.id === newId)) {
      ui.notifications.warn("A theme with that name already exists.");
      return;
    }
    lib.push({ id: newId, name: newName, colors: { ...entry.colors } });
    await this.setLibrary(lib);
    this.render(false);
  }

  async _onDelete(id) {
    const lib = this.getLibrary();
    const entry = lib.find((e) => e.id === id);
    if (!entry) return;
    const confirmed = await Dialog.confirm({
      title: "Delete Theme?",
      content: `<p>Permanently delete "<strong>${entry.name}</strong>"? This cannot be undone.</p>`,
    });
    if (!confirmed) return;
    await this.setLibrary(lib.filter((e) => e.id !== id));
    this.render(false);
  }

  _onExport(html) {
    const data = {
      name: this.loadedName || "Untitled Theme",
      colors: this.colors,
    };
    const textarea = html.find("#ctd-io-textarea");
    textarea.removeClass("hidden").val(JSON.stringify(data, null, 2));
    html.find("#ctd-import-confirm").addClass("hidden");
  }

  _onImport(html) {
    const raw = html.find("#ctd-io-textarea").val();
    let data;
    try {
      data = JSON.parse(raw);
    } catch (err) {
      ui.notifications.error("Invalid JSON — could not parse theme data.");
      return;
    }
    if (!data.colors || !ROW_ORDER.every((k) => typeof data.colors[k] === "string")) {
      ui.notifications.error("JSON is missing required color fields.");
      return;
    }
    this.colors = { ...data.colors };
    this.seed = data.colors.accent;
    this.loadedName = data.name || null;
    Object.keys(this.rowSelection).forEach((k) => { this.rowSelection[k] = -1; });
    ui.notifications.info("Theme loaded into editor. Review and Save to add it to your library.");
    this.render(false);
  }

  async _promptText(title, label, defaultValue) {
    return Dialog.prompt({
      title,
      content: `<p>${label}</p><input type="text" id="ctd-prompt-input" value="${defaultValue}" style="width:100%">`,
      callback: (html) => html.find("#ctd-prompt-input").val(),
      rejectClose: false,
    });
  }
}
