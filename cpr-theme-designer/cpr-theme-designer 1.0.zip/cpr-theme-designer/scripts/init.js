import { generateLibraryCSS } from "./css-generator.js";
import { CprThemeDesignerApp } from "./theme-designer-app.js";

const MODULE_ID = "cpr-theme-designer";

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "themeLibrary", {
    scope: "world",
    config: false,
    type: Array,
    default: [],
  });

  // Register one cprcThemes entry per saved library palette.
  // NOTE: cprcThemes registration only happens here, at init. Themes
  // saved/edited after this point won't appear in CPR's dropdown until
  // a Foundry reload (F5). See Theme_Designer.md Section 3.
  const library = game.settings.get(MODULE_ID, "themeLibrary") || [];
  const cprcThemes = {};
  library.forEach((entry) => {
    cprcThemes[entry.id] = entry.name;
  });
  game.modules.get(MODULE_ID).cprcThemes = cprcThemes;
});

Hooks.once("ready", () => {
  const library = game.settings.get(MODULE_ID, "themeLibrary") || [];
  if (!library.length) return;

  const css = generateLibraryCSS(library);
  let styleEl = document.getElementById("cpr-theme-designer-injected");
  if (!styleEl) {
    styleEl = document.createElement("style");
    styleEl.id = "cpr-theme-designer-injected";
    document.head.appendChild(styleEl);
  }
  styleEl.textContent = css;
});

// Launch button: Settings sidebar -> "CPR Theme Designer"
Hooks.on("renderSettings", (app, html) => {
  const button = $(`<button type="button" data-action="cpr-theme-designer">
    <i class="fas fa-palette"></i> CPR Theme Designer
  </button>`);
  button.on("click", () => new CprThemeDesignerApp().render(true));

  const target = html.find("#settings-game, .settings-sidebar, #game-details").first();
  if (target.length) {
    target.append(button);
  } else {
    html.append(button);
  }
});
