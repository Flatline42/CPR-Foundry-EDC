/**
 * CPR Theme Designer — Color Math & CSS Generation
 *
 * Pure functions only. No Foundry API calls in this file, so it can be
 * unit-tested or reused outside the Application context.
 *
 * See Theme_Designer.md Section 4 for the design rationale behind the
 * shade/hue generation split.
 */

// ─────────────────────────────────────────────────────────
// Color Conversion (hex <-> HSL)
// ─────────────────────────────────────────────────────────

/** #rrggbb -> {h, s, l} (h: 0-360, s/l: 0-100) */
function hexToHsl(hex) {
  let r = parseInt(hex.slice(1, 3), 16) / 255;
  let g = parseInt(hex.slice(3, 5), 16) / 255;
  let b = parseInt(hex.slice(5, 7), 16) / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h;
  let s;
  const l = (max + min) / 2;

  if (max === min) {
    h = 0;
    s = 0;
  } else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)); break;
      case g: h = ((b - r) / d + 2); break;
      case b: h = ((r - g) / d + 4); break;
      default: h = 0;
    }
    h *= 60;
  }
  return { h, s: s * 100, l: l * 100 };
}

/** {h, s, l} -> #rrggbb */
function hslToHex(h, s, l) {
  h = ((h % 360) + 360) % 360;
  s = Math.max(0, Math.min(100, s)) / 100;
  l = Math.max(0, Math.min(100, l)) / 100;

  const c = (1 - Math.abs(2 * l - 1)) * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = l - c / 2;
  let r = 0;
  let g = 0;
  let b = 0;

  if (h < 60) { r = c; g = x; b = 0; }
  else if (h < 120) { r = x; g = c; b = 0; }
  else if (h < 180) { r = 0; g = c; b = x; }
  else if (h < 240) { r = 0; g = x; b = c; }
  else if (h < 300) { r = x; g = 0; b = c; }
  else { r = c; g = 0; b = x; }

  const toHex = (v) => {
    const n = Math.round((v + m) * 255);
    return n.toString(16).padStart(2, "0");
  };
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

/** Relative luminance per WCAG, for contrast decisions (0-1). */
function relativeLuminance(hex) {
  const chan = (c) => {
    c /= 255;
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
  };
  const r = chan(parseInt(hex.slice(1, 3), 16));
  const g = chan(parseInt(hex.slice(3, 5), 16));
  const b = chan(parseInt(hex.slice(5, 7), 16));
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/**
 * Given a background hex, return whichever of near-black / near-white
 * gives better contrast. Used for hardcoded-override text (e.g. active
 * tab text) rather than picking one of the 8 theme colors blindly —
 * this is the fix for the Watson Nights invisible-tab-text problem.
 * See Theme_Designer.md Section 4.4.
 */
function getReadableTextColor(backgroundHex, darkHex = "#000011", lightHex = "#f0f0f0") {
  const bgLum = relativeLuminance(backgroundHex);
  const darkLum = relativeLuminance(darkHex);
  const lightLum = relativeLuminance(lightHex);

  const contrastWith = (lum1, lum2) => {
    const lighter = Math.max(lum1, lum2);
    const darker = Math.min(lum1, lum2);
    return (lighter + 0.05) / (darker + 0.05);
  };

  const contrastDark = contrastWith(bgLum, darkLum);
  const contrastLight = contrastWith(bgLum, lightLum);
  return contrastDark >= contrastLight ? darkHex : lightHex;
}

// ─────────────────────────────────────────────────────────
// Suggestion Generation
// ─────────────────────────────────────────────────────────

/**
 * Shade mode: same hue as seed, 3 variants differing in lightness/
 * saturation. Good for: accent, secondary highlight, body text.
 */
function generateShades(seedHex) {
  const { h, s } = hexToHsl(seedHex);
  return [
    hslToHex(h, Math.min(100, s + 10), 65), // brighter/lighter
    seedHex,                                 // the seed itself
    hslToHex(h, Math.max(0, s - 15), 30),    // darker/muted
  ];
}

/**
 * Hue mode: different hue from the seed, similar "role weight"
 * (dark & desaturated, suitable for structural/background use).
 * Good for: background, header, structural/borders, input bg.
 *
 * Offsets are analogous-ish shifts rather than a strict complementary
 * 180deg — pure complementary pairing is what caused the Watson Nights
 * vibration problem, so this deliberately avoids exact opposites.
 */
function generateHueShifts(seedHex) {
  const { h } = hexToHsl(seedHex);
  return [
    hslToHex(h + 40, 45, 12),   // analogous-warm, dark & muted
    hslToHex(h - 160, 45, 8),   // near-opposite but desaturated + very dark
    hslToHex(h - 40, 45, 12),   // analogous-cool, dark & muted
  ];
}

/** Per-row default generation mode. See Theme_Designer.md Section 4.3. */
const DEFAULT_MODE = {
  background: "hue",
  header: "hue",
  structural: "hue",
  accent: "shade",
  secondary: "shade",
  text: "shade",
  inputBg: "hue",
  rowEven: "hue",
};

const ROW_ORDER = [
  "background", "header", "structural", "accent",
  "text", "secondary", "inputBg", "rowEven",
];

/** Returns 3 suggested hex swatches for a given row, based on mode. */
function generateSuggestions(rowKey, seedHex, mode) {
  const useMode = mode || DEFAULT_MODE[rowKey] || "shade";
  return useMode === "hue" ? generateHueShifts(seedHex) : generateShades(seedHex);
}

// ─────────────────────────────────────────────────────────
// CSS Emission
// ─────────────────────────────────────────────────────────

/**
 * colors: {
 *   background, header, structural, accent, text, secondary,
 *   inputBg, rowEven
 * } — all #rrggbb hex strings.
 *
 * themeId: no-hyphen string, matches the cprcThemes key and the
 * html[data-cpr-theme="..."] selector. See Section 3 hard constraint.
 */
function generateThemeCSS(themeId, colors) {
  const {
    background, header, structural, accent, text, secondary, inputBg, rowEven,
  } = colors;

  const activeTabText = getReadableTextColor(structural);
  const itemsHeaderBorderBottom = accent;

  return `html[data-cpr-theme="${themeId}"] {

  /* Base Palette */
  --cpr-dark-background:  ${background};
  --cpr-dark-header:      ${header};
  --cpr-dark-main:        ${structural};
  --cpr-dark-red:         ${accent};
  --cpr-dark-text-main:   ${text};
  --cpr-dark-bluish-grey: ${secondary};

  /* Background: Structural */
  --cpr-background-border:                  var(--cpr-dark-main);
  --cpr-background-box:                     var(--cpr-dark-background);
  --cpr-background-chat-border:             ${structural};
  --cpr-background-chat-card-block-before:  ${header};
  --cpr-background-chat-card-block:         var(--cpr-dark-main);
  --cpr-background-chat-card:               var(--cpr-dark-background);
  --cpr-background-code:                    ${inputBg};
  --cpr-background-content-link:            ${header};
  --cpr-background-cyberdeck-section-header:${rowEven};
  --cpr-background-dialog-border:           var(--cpr-dark-main);
  --cpr-background-dialog-hr-gradient-end:    ${structural};
  --cpr-background-dialog-hr-gradient-middle: ${secondary};
  --cpr-background-dialog-hr-gradient-start:  ${structural};
  --cpr-background-dialog-selected:         ${rowEven};
  --cpr-background-editor-button-active:    ${rowEven};
  --cpr-background-editor-button-hover:     ${rowEven};
  --cpr-background-editor-button-selected:  var(--cpr-color-dark-grey);
  --cpr-background-editor-button:           ${structural};
  --cpr-background-editor-header:           var(--cpr-dark-header);
  --cpr-background-foundry-hover:           var(--cpr-dark-main);
  --cpr-background-foundry-input:           ${inputBg};
  --cpr-background-header:                  var(--cpr-dark-header);
  --cpr-background-journal-blockquote:      ${rowEven};
  --cpr-background-pill:                    var(--cpr-dark-header);
  --cpr-background-row-even:                ${rowEven};
  --cpr-background-row-odd:                 var(--cpr-dark-background);
  --cpr-background-tab-active:              var(--cpr-dark-main);
  --cpr-background-tab-inactive:            ${header};
  --cpr-background-tab-underlay:            ${structural};
  --cpr-background-toggle-checked:          ${accent};
  --cpr-background-window:                  var(--cpr-dark-background);

  /* Text Colors */
  --cpr-text-chat-failure:      #e53535;
  --cpr-text-chat-normal:       var(--cpr-dark-text-main);
  --cpr-text-content-link-icon: ${text};
  --cpr-text-dir-list:          var(--cpr-dark-text-main);
  --cpr-text-editor-button:     var(--cpr-color-black);
  --cpr-text-editor-header:     var(--cpr-dark-text-main);
  --cpr-text-foundry-hint:      ${secondary};
  --cpr-text-foundry-hover:     ${accent};
  --cpr-text-foundry-input:     var(--cpr-dark-text-main);
  --cpr-text-header-arrow:      var(--cpr-dark-main);
  --cpr-text-header-line-box:   ${secondary};
  --cpr-text-header-line:       var(--cpr-dark-main);
  --cpr-text-header:            var(--cpr-dark-text-main);
  --cpr-text-hint:              ${secondary};
  --cpr-text-icon-dimmed:       ${header};
  --cpr-text-icon-highlight:    var(--cpr-dark-red);
  --cpr-text-icon-normal:       ${secondary};
  --cpr-text-mook-normal:       var(--cpr-dark-text-main);
  --cpr-text-normal:            var(--cpr-dark-text-main);
  --cpr-text-pill:              var(--cpr-dark-text-main);
  --cpr-text-tab-normal:        var(--cpr-dark-text-main);
  --cpr-text-window:            var(--cpr-dark-text-main);

  /* Foundry Core UI Overrides */
  --color-border-light-1:       ${structural};
  --color-border-light-primary: ${structural};
  --color-shadow-primary:       ${secondary};

  /* Icon Colors */
  --cpr-icon-actor-image-overlay-border: ${accent};
  --cpr-icon-actor-image-overlay:        var(--cpr-color-white);
}

/* Hardcoded Overrides — see Theme_Designer.md Section 4.2 */

html[data-cpr-theme="${themeId}"] .items-header {
  background-color: ${inputBg} !important;
  border-top: 1px solid ${accent};
  border-bottom: 1px solid ${itemsHeaderBorderBottom};
}

html[data-cpr-theme="${themeId}"] .tab-label.active {
  color: ${activeTabText} !important;
}
`;
}

/** Concatenates generateThemeCSS for every entry in a themeLibrary array. */
function generateLibraryCSS(themeLibrary) {
  return themeLibrary
    .map((entry) => generateThemeCSS(entry.id, entry.colors))
    .join("\n");
}

// Exported as a plain object attached to the module namespace by init.js
// (see scripts/init.js) rather than ES module export, to keep this file
// loadable both as a Foundry esmodule and easily copy-pastable/testable.
export {
  hexToHsl,
  hslToHex,
  relativeLuminance,
  getReadableTextColor,
  generateShades,
  generateHueShifts,
  generateSuggestions,
  generateThemeCSS,
  generateLibraryCSS,
  DEFAULT_MODE,
  ROW_ORDER,
};
